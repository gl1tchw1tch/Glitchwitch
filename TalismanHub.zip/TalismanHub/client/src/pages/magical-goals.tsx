import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { MagicalGoalCard } from "@/components/magical-goal-card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import type { MagicalGoal, MagicalGoalCategory } from "@shared/schema";
import { Filter, Search, BookOpen } from "lucide-react";
import { Link } from "wouter";

export default function MagicalGoals() {
  const [filterCategory, setFilterCategory] = useState<MagicalGoalCategory | null>(null);
  const [searchQuery, setSearchQuery] = useState("");

  // Fetch all magical goals
  const { data: goals, isLoading } = useQuery<MagicalGoal[]>({
    queryKey: ["/api/magical-goals", filterCategory],
    queryFn: async () => {
      const url = filterCategory 
        ? `/api/magical-goals?category=${encodeURIComponent(filterCategory)}`
        : "/api/magical-goals";
      const response = await fetch(url);
      if (!response.ok) throw new Error("Failed to fetch magical goals");
      return response.json();
    },
  });

  // Filter goals by search query
  const filteredGoals = goals?.filter((goal) =>
    goal.purpose.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const categories: MagicalGoalCategory[] = [
    "Divination",
    "Adversarial",
    "Spirit Work",
    "Alchemy",
    "Warding",
    "Fortune/Wealth",
    "Love/Attraction",
    "Transformation",
    "Healing",
    "Malefic Work",
    "Knowledge",
    "Elemental",
    "Success",
    "Defense/Warding",
  ];

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="sticky top-0 z-40 backdrop-blur-lg bg-background/80 border-b border-border">
        <div className="max-w-7xl mx-auto px-4 md:px-8 py-4">
          <div className="flex items-center justify-between">
            <div>
              <div className="flex items-center gap-3 mb-1">
                <Link href="/">
                  <Button variant="ghost" size="sm" data-testid="link-home">
                    ← Back to Transits
                  </Button>
                </Link>
              </div>
              <h1 className="text-3xl md:text-4xl font-serif font-bold text-foreground" data-testid="text-page-title">
                Magical Goals Compendium
              </h1>
              <p className="text-muted-foreground mt-1">
                134 telismatic squares from the sacred tradition
              </p>
            </div>
            <BookOpen className="w-8 h-8 text-primary" />
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 md:px-8 py-8">
        {/* Search & Filter Controls */}
        <div className="mb-8 space-y-4">
          {/* Search Bar */}
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-muted-foreground" />
            <Input
              type="search"
              placeholder="Search by purpose..."
              className="pl-10"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              data-testid="input-search"
            />
          </div>

          {/* Category Filters */}
          <div>
            <div className="flex items-center gap-2 mb-3">
              <Filter className="w-4 h-4 text-muted-foreground" />
              <span className="text-sm text-muted-foreground font-medium">Filter by Category:</span>
            </div>
            <div className="flex flex-wrap gap-2">
              <Badge
                variant={filterCategory === null ? "default" : "secondary"}
                className="cursor-pointer hover-elevate"
                onClick={() => setFilterCategory(null)}
                data-testid="filter-all-categories"
              >
                All Categories
              </Badge>
              {categories.map((category) => (
                <Badge
                  key={category}
                  variant={filterCategory === category ? "default" : "secondary"}
                  className="cursor-pointer hover-elevate"
                  onClick={() => setFilterCategory(category)}
                  data-testid={`filter-${category.toLowerCase().replace(/[\/\s]/g, '-')}`}
                >
                  {category}
                </Badge>
              ))}
            </div>
          </div>
        </div>

        {/* Results Count */}
        {filteredGoals && (
          <p className="text-sm text-muted-foreground mb-4" data-testid="text-results-count">
            Showing {filteredGoals.length} {filteredGoals.length === 1 ? "square" : "squares"}
          </p>
        )}

        {/* Goals Grid */}
        {isLoading ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {[1, 2, 3, 4, 5, 6].map((i) => (
              <div key={i} className="h-48 bg-card/50 rounded-lg animate-pulse" />
            ))}
          </div>
        ) : filteredGoals && filteredGoals.length > 0 ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {filteredGoals.map((goal) => (
              <MagicalGoalCard key={goal.squareNo} goal={goal} />
            ))}
          </div>
        ) : (
          <div className="text-center py-12">
            <p className="text-muted-foreground">
              No magical goals found matching your criteria.
            </p>
          </div>
        )}
      </main>
    </div>
  );
}
