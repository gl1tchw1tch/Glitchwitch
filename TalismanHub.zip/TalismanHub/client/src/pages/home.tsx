import { useState, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { NatalContextCard } from "@/components/natal-context-card";
import { TransitCard } from "@/components/transit-card";
import { BlueprintView } from "@/components/blueprint-view";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import type { Transit, NatalContext, Blueprint } from "@shared/schema";
import { Sparkles, Filter } from "lucide-react";

export default function Home() {
  const [selectedTransitId, setSelectedTransitId] = useState<number | null>(null);
  const [selectedBlueprint, setSelectedBlueprint] = useState<Blueprint | null>(null);
  const [filterPlanet, setFilterPlanet] = useState<string | null>(null);

  // Fetch natal context
  const { data: natalContext } = useQuery<NatalContext>({
    queryKey: ["/api/natal-context"],
  });

  // Fetch transits with optional filter
  const { data: transits, isLoading: transitsLoading } = useQuery<Transit[]>({
    queryKey: ["/api/transits", filterPlanet],
    queryFn: async () => {
      const url = filterPlanet 
        ? `/api/transits?luminary=${filterPlanet}`
        : "/api/transits";
      const response = await fetch(url);
      if (!response.ok) throw new Error("Failed to fetch transits");
      return response.json();
    },
  });

  // Fetch blueprint when transit is selected
  const { data: blueprint, isLoading: blueprintLoading } = useQuery<Blueprint>({
    queryKey: ["/api/transits", selectedTransitId, "blueprint"],
    queryFn: async () => {
      if (selectedTransitId === null) throw new Error("No transit selected");
      const response = await fetch(`/api/transits/${selectedTransitId}/blueprint`);
      if (!response.ok) throw new Error("Failed to fetch blueprint");
      return response.json();
    },
    enabled: selectedTransitId !== null,
  });

  // Show blueprint when it's loaded
  useEffect(() => {
    if (blueprint && selectedTransitId) {
      setSelectedBlueprint(blueprint);
      setSelectedTransitId(null);
    }
  }, [blueprint, selectedTransitId]);

  const planets = ["Sun", "Moon", "Mars", "Mercury", "Jupiter", "Venus", "Saturn"];

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="sticky top-0 z-40 backdrop-blur-lg bg-background/80 border-b border-border">
        <div className="max-w-7xl mx-auto px-4 md:px-8 py-4">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-3xl md:text-4xl font-serif font-bold text-foreground" data-testid="text-app-title">
                Telismatic Election Hub
              </h1>
              <p className="text-muted-foreground mt-1">
                Sacred blueprint generation through celestial elections
              </p>
            </div>
            <Sparkles className="w-8 h-8 text-primary animate-glow-pulse" />
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 md:px-8 py-8">
        {/* Natal Context */}
        {natalContext && (
          <div className="mb-8">
            <NatalContextCard natalContext={natalContext} />
          </div>
        )}

        {/* Transits Section */}
        <div>
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-2xl font-serif font-semibold text-foreground">
              Upcoming Transits
            </h2>
            <div className="flex items-center gap-2">
              <Filter className="w-4 h-4 text-muted-foreground" />
              <span className="text-sm text-muted-foreground">Filter:</span>
            </div>
          </div>

          {/* Planet Filters */}
          <div className="flex flex-wrap gap-2 mb-6">
            <Badge
              variant={filterPlanet === null ? "default" : "secondary"}
              className="cursor-pointer hover-elevate"
              onClick={() => setFilterPlanet(null)}
              data-testid="filter-all"
            >
              All Transits
            </Badge>
            {planets.map((planet) => (
              <Badge
                key={planet}
                variant={filterPlanet === planet ? "default" : "secondary"}
                className="cursor-pointer hover-elevate"
                onClick={() => setFilterPlanet(planet)}
                data-testid={`filter-${planet.toLowerCase()}`}
              >
                {planet}
              </Badge>
            ))}
          </div>

          {/* Transit Cards */}
          {transitsLoading ? (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {[1, 2, 3, 4].map((i) => (
                <div key={i} className="h-64 bg-card/50 rounded-lg animate-pulse" />
              ))}
            </div>
          ) : transits && transits.length > 0 ? (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {transits.map((transit) => (
                <TransitCard
                  key={transit.id}
                  transit={transit}
                  onGenerateBlueprint={() => setSelectedTransitId(transit.id)}
                />
              ))}
            </div>
          ) : (
            <div className="text-center py-12">
              <p className="text-muted-foreground">
                No transits found for the selected filter.
              </p>
            </div>
          )}
        </div>

        {/* Loading Overlay for Blueprint */}
        {blueprintLoading && (
          <div className="fixed inset-0 bg-background/95 backdrop-blur-sm z-50 flex items-center justify-center">
            <div className="text-center">
              <Sparkles className="w-16 h-16 text-primary animate-glow-pulse mx-auto mb-4" />
              <p className="text-xl font-serif text-foreground">
                Generating Sacred Blueprint...
              </p>
              <p className="text-muted-foreground mt-2">
                Consulting the celestial correspondences
              </p>
            </div>
          </div>
        )}

        {/* Blueprint View Modal */}
        {selectedBlueprint && (
          <BlueprintView
            blueprint={selectedBlueprint}
            onClose={() => setSelectedBlueprint(null)}
          />
        )}
      </main>
    </div>
  );
}
