interface PlanetaryIconProps {
  planet: "Sun" | "Moon" | "Mars" | "Mercury" | "Jupiter" | "Venus" | "Saturn";
  className?: string;
}

export function PlanetaryIcon({ planet, className = "w-8 h-8" }: PlanetaryIconProps) {
  const icons = {
    Sun: (
      <svg viewBox="0 0 24 24" fill="none" className={className}>
        <circle cx="12" cy="12" r="5" fill="currentColor" />
        {[0, 45, 90, 135, 180, 225, 270, 315].map((angle) => (
          <line
            key={angle}
            x1="12"
            y1="12"
            x2={12 + Math.cos((angle * Math.PI) / 180) * 9}
            y2={12 + Math.sin((angle * Math.PI) / 180) * 9}
            stroke="currentColor"
            strokeWidth="1.5"
            strokeLinecap="round"
          />
        ))}
      </svg>
    ),
    Moon: (
      <svg viewBox="0 0 24 24" fill="none" className={className}>
        <path
          d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z"
          fill="currentColor"
        />
      </svg>
    ),
    Mars: (
      <svg viewBox="0 0 24 24" fill="none" className={className}>
        <circle cx="10" cy="14" r="6" stroke="currentColor" strokeWidth="2" fill="none" />
        <line x1="14.5" y1="9.5" x2="20" y2="4" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
        <line x1="20" y1="4" x2="20" y2="8" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
        <line x1="20" y1="4" x2="16" y2="4" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
      </svg>
    ),
    Mercury: (
      <svg viewBox="0 0 24 24" fill="none" className={className}>
        <circle cx="12" cy="12" r="5" stroke="currentColor" strokeWidth="2" fill="none" />
        <line x1="12" y1="7" x2="12" y2="3" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
        <line x1="9" y1="5" x2="15" y2="5" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
        <line x1="12" y1="17" x2="12" y2="21" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
        <line x1="10" y1="19" x2="14" y2="19" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
      </svg>
    ),
    Jupiter: (
      <svg viewBox="0 0 24 24" fill="none" className={className}>
        <line x1="7" y1="4" x2="7" y2="20" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
        <path d="M7 10 Q15 10, 15 15 Q15 18, 12 18" stroke="currentColor" strokeWidth="2" fill="none" />
        <line x1="4" y1="16" x2="10" y2="16" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
      </svg>
    ),
    Venus: (
      <svg viewBox="0 0 24 24" fill="none" className={className}>
        <circle cx="12" cy="9" r="5" stroke="currentColor" strokeWidth="2" fill="none" />
        <line x1="12" y1="14" x2="12" y2="21" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
        <line x1="9" y1="18" x2="15" y2="18" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
      </svg>
    ),
    Saturn: (
      <svg viewBox="0 0 24 24" fill="none" className={className}>
        <line x1="8" y1="4" x2="8" y2="18" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
        <path d="M8 5 C12 5, 16 7, 16 10 C16 13, 12 15, 8 15" stroke="currentColor" strokeWidth="2" fill="none" />
        <line x1="4" y1="17" x2="12" y2="17" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
      </svg>
    ),
  };

  return icons[planet];
}

export function getPlanetaryColor(planet: "Sun" | "Moon" | "Mars" | "Mercury" | "Jupiter" | "Venus" | "Saturn"): string {
  const colors = {
    Sun: "text-sun",
    Moon: "text-moon",
    Mars: "text-mars",
    Mercury: "text-mercury",
    Jupiter: "text-jupiter",
    Venus: "text-venus",
    Saturn: "text-saturn",
  };
  return colors[planet];
}

export function getPlanetaryBorderColor(planet: "Sun" | "Moon" | "Mars" | "Mercury" | "Jupiter" | "Venus" | "Saturn"): string {
  const colors = {
    Sun: "border-sun",
    Moon: "border-moon",
    Mars: "border-mars",
    Mercury: "border-mercury",
    Jupiter: "border-jupiter",
    Venus: "border-venus",
    Saturn: "border-saturn",
  };
  return colors[planet];
}

export function getPlanetaryBgColor(planet: "Sun" | "Moon" | "Mars" | "Mercury" | "Jupiter" | "Venus" | "Saturn"): string {
  const colors = {
    Sun: "bg-sun",
    Moon: "bg-moon",
    Mars: "bg-mars",
    Mercury: "bg-mercury",
    Jupiter: "bg-jupiter",
    Venus: "bg-venus",
    Saturn: "bg-saturn",
  };
  return colors[planet];
}
