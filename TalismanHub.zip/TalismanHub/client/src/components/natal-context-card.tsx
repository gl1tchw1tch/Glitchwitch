import { Card } from "@/components/ui/card";
import type { NatalContext } from "@shared/schema";

interface NatalContextCardProps {
  natalContext: NatalContext;
}

export function NatalContextCard({ natalContext }: NatalContextCardProps) {
  return (
    <Card className="p-6 border-l-4 border-l-primary" data-testid="card-natal-context">
      <h2 className="text-2xl font-serif font-semibold mb-4 text-primary">
        Natal Context
      </h2>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
        <div>
          <p className="text-muted-foreground mb-1">Natal Chart ID</p>
          <p className="font-semibold text-foreground" data-testid="text-natal-name">
            {natalContext.name}
          </p>
        </div>
        <div>
          <p className="text-muted-foreground mb-1">Key Focus Aspect</p>
          <p className="font-semibold text-destructive" data-testid="text-key-aspect">
            {natalContext.keyAspect}
          </p>
        </div>
        <div>
          <p className="text-muted-foreground mb-1">DOB / Time / Location</p>
          <p className="text-foreground" data-testid="text-birth-info">
            {natalContext.dob} @ {natalContext.tob} / {natalContext.location}
          </p>
        </div>
        <div>
          <p className="text-muted-foreground mb-1">Core Affliction</p>
          <p className="text-foreground" data-testid="text-mercury-sign">
            Mercury in <span className="font-semibold">{natalContext.natalMercurySign}</span>
          </p>
        </div>
      </div>
    </Card>
  );
}
