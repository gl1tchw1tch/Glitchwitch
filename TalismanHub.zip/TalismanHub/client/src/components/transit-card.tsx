import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { PlanetaryIcon, getPlanetaryColor, getPlanetaryBorderColor } from "./planetary-icon";
import type { Transit } from "@shared/schema";
import { format } from "date-fns";
import { Sparkles } from "lucide-react";

interface TransitCardProps {
  transit: Transit;
  onGenerateBlueprint: () => void;
}

export function TransitCard({ transit, onGenerateBlueprint }: TransitCardProps) {
  const planetColor = getPlanetaryColor(transit.luminary);
  const borderColor = getPlanetaryBorderColor(transit.luminary);

  return (
    <Card 
      className={`p-6 border-l-4 ${borderColor} hover-elevate`}
      data-testid={`card-transit-${transit.id}`}
    >
      <div className="flex items-start justify-between gap-4">
        <div className="flex-1">
          <div className="flex items-center gap-3 mb-3">
            <div className={planetColor}>
              <PlanetaryIcon planet={transit.luminary} className="w-10 h-10" />
            </div>
            <div>
              <h3 className={`text-xl font-serif font-semibold ${planetColor}`} data-testid={`text-luminary-${transit.id}`}>
                {transit.luminary}
              </h3>
              <p className="text-sm text-muted-foreground" data-testid={`text-date-${transit.id}`}>
                {format(new Date(transit.date), "EEE, MMM d, yyyy")} @ {transit.time}
              </p>
            </div>
          </div>
          
          <div className="space-y-2 mb-4">
            <div>
              <span className="text-xs text-muted-foreground uppercase tracking-wide">Aspect</span>
              <p className="text-foreground font-medium" data-testid={`text-aspect-${transit.id}`}>
                {transit.aspect} to {transit.target}
              </p>
              <p className="text-sm text-muted-foreground">{transit.sign}</p>
            </div>
            
            <div>
              <span className="text-xs text-muted-foreground uppercase tracking-wide">Intent</span>
              <p className="text-foreground italic" data-testid={`text-intent-${transit.id}`}>
                {transit.intent}
              </p>
            </div>
          </div>
        </div>
      </div>
      
      <Button
        onClick={onGenerateBlueprint}
        className="w-full mt-2"
        data-testid={`button-generate-blueprint-${transit.id}`}
      >
        <Sparkles className="w-4 h-4 mr-2" />
        Generate Blueprint
      </Button>
    </Card>
  );
}
