import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { SacredGeometry } from "./sacred-geometry";
import { PlanetaryIcon, getPlanetaryColor, getPlanetaryBgColor } from "./planetary-icon";
import type { Blueprint } from "@shared/schema";
import { format } from "date-fns";
import { X, Download } from "lucide-react";

interface BlueprintViewProps {
  blueprint: Blueprint;
  onClose: () => void;
}

export function BlueprintView({ blueprint, onClose }: BlueprintViewProps) {
  const { transit, luminary, spirit, combinedColors } = blueprint;
  const planetColor = getPlanetaryColor(transit.luminary);
  const planetBgColor = getPlanetaryBgColor(transit.luminary);

  return (
    <div className="fixed inset-0 bg-background/95 backdrop-blur-sm z-50 overflow-y-auto p-4 md:p-8">
      <div className="max-w-5xl mx-auto">
        <div className="flex justify-between items-start mb-6">
          <div>
            <h1 className="text-4xl font-serif font-bold text-foreground mb-2" data-testid="text-blueprint-title">
              Talismanic Blueprint
            </h1>
            <p className="text-muted-foreground">
              Generated on {format(new Date(blueprint.generatedAt), "PPpp")}
            </p>
          </div>
          <Button variant="ghost" size="icon" onClick={onClose} data-testid="button-close-blueprint">
            <X className="w-6 h-6" />
          </Button>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Left Column: Sacred Geometry & Core Info */}
          <Card className={`p-8 border-l-4 ${getPlanetaryBgColor(transit.luminary)}/10`} data-testid="card-blueprint-geometry">
            <div className="flex flex-col items-center mb-6">
              <div className={planetColor}>
                <SacredGeometry
                  shape={luminary.shape}
                  number={luminary.number}
                  color={planetColor}
                  className="w-64 h-64 mb-4"
                />
              </div>
              <div className="text-center">
                <h2 className={`text-3xl font-serif font-bold ${planetColor} mb-2`} data-testid="text-blueprint-luminary">
                  {transit.luminary}
                </h2>
                <p className="text-muted-foreground mb-4">
                  Intelligence: <span className="font-semibold text-foreground" data-testid="text-blueprint-intelligence">{spirit.name}</span>
                </p>
              </div>
            </div>

            <div className="space-y-4">
              <div className="p-4 bg-card/50 rounded-lg border border-card-border">
                <p className="text-xs text-muted-foreground uppercase tracking-wide mb-1">Geometric Form</p>
                <p className="font-semibold text-foreground" data-testid="text-blueprint-shape">{luminary.shape}</p>
              </div>
              
              <div className="p-4 bg-card/50 rounded-lg border border-card-border">
                <p className="text-xs text-muted-foreground uppercase tracking-wide mb-1">Qabalistic Number</p>
                <p className="text-3xl font-serif font-bold text-foreground" data-testid="text-blueprint-number">{luminary.number}</p>
              </div>
              
              <div className="p-4 bg-card/50 rounded-lg border border-card-border">
                <p className="text-xs text-muted-foreground uppercase tracking-wide mb-1">Function</p>
                <p className="font-medium text-foreground" data-testid="text-blueprint-function">{luminary.function}</p>
              </div>
            </div>
          </Card>

          {/* Right Column: Election Details & Design Specs */}
          <div className="space-y-6">
            <Card className="p-6" data-testid="card-blueprint-election">
              <h3 className="text-xl font-serif font-semibold mb-4 text-foreground">Election Details</h3>
              <div className="space-y-3">
                <div>
                  <p className="text-xs text-muted-foreground uppercase tracking-wide">Date & Time</p>
                  <p className="text-lg font-semibold text-foreground" data-testid="text-blueprint-datetime">
                    {format(new Date(transit.date), "EEEE, MMMM d, yyyy")}
                  </p>
                  <p className="text-foreground">{transit.time}</p>
                </div>
                
                <div>
                  <p className="text-xs text-muted-foreground uppercase tracking-wide">Aspect</p>
                  <p className="text-foreground font-medium" data-testid="text-blueprint-aspect">
                    {transit.aspect} to {transit.target}
                  </p>
                  <p className="text-sm text-muted-foreground">{transit.sign}</p>
                </div>
                
                <div>
                  <p className="text-xs text-muted-foreground uppercase tracking-wide">Intent</p>
                  <p className="text-foreground italic" data-testid="text-blueprint-intent">{transit.intent}</p>
                </div>
              </div>
            </Card>

            <Card className="p-6" data-testid="card-blueprint-colors">
              <h3 className="text-xl font-serif font-semibold mb-4 text-foreground">Color Palette</h3>
              <div className="flex flex-wrap gap-2 mb-4">
                {combinedColors.map((color, index) => (
                  <Badge
                    key={index}
                    variant="secondary"
                    className="text-xs"
                    data-testid={`badge-color-${index}`}
                  >
                    {color}
                  </Badge>
                ))}
              </div>
              <p className="text-sm text-muted-foreground">
                Primary colors from {transit.luminary}, refined with secondary hues from the Intelligence {spirit.name}
              </p>
            </Card>

            <Card className="p-6" data-testid="card-blueprint-symbols">
              <h3 className="text-xl font-serif font-semibold mb-4 text-foreground">Symbolic Motifs</h3>
              <div className="space-y-2">
                {spirit.symbols.map((symbol, index) => (
                  <div
                    key={index}
                    className="p-3 bg-card/50 rounded border border-card-border"
                    data-testid={`text-symbol-${index}`}
                  >
                    <p className="text-foreground">{symbol}</p>
                  </div>
                ))}
              </div>
            </Card>

            <Button className="w-full" variant="outline" data-testid="button-export-blueprint">
              <Download className="w-4 h-4 mr-2" />
              Export Blueprint
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}
