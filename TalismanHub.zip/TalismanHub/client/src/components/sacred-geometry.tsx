interface SacredGeometryProps {
  shape: string;
  number: number;
  color: string;
  className?: string;
}

export function SacredGeometry({ shape, number, color, className = "w-48 h-48" }: SacredGeometryProps) {
  const renderShape = () => {
    const shapeKey = shape.toLowerCase();
    
    if (shapeKey.includes("triangle")) {
      return (
        <svg viewBox="0 0 200 200" className={className}>
          <defs>
            <filter id="glow">
              <feGaussianBlur stdDeviation="2" result="coloredBlur"/>
              <feMerge>
                <feMergeNode in="coloredBlur"/>
                <feMergeNode in="SourceGraphic"/>
              </feMerge>
            </filter>
          </defs>
          <polygon
            points="100,30 170,150 30,150"
            fill="none"
            stroke="currentColor"
            strokeWidth="3"
            filter="url(#glow)"
          />
          <text
            x="100"
            y="115"
            textAnchor="middle"
            className="text-4xl font-serif font-bold"
            fill="currentColor"
          >
            {number}
          </text>
        </svg>
      );
    }
    
    if (shapeKey.includes("square")) {
      return (
        <svg viewBox="0 0 200 200" className={className}>
          <defs>
            <filter id="glow">
              <feGaussianBlur stdDeviation="2" result="coloredBlur"/>
              <feMerge>
                <feMergeNode in="coloredBlur"/>
                <feMergeNode in="SourceGraphic"/>
              </feMerge>
            </filter>
          </defs>
          <rect
            x="40"
            y="40"
            width="120"
            height="120"
            fill="none"
            stroke="currentColor"
            strokeWidth="3"
            filter="url(#glow)"
          />
          <text
            x="100"
            y="115"
            textAnchor="middle"
            className="text-4xl font-serif font-bold"
            fill="currentColor"
          >
            {number}
          </text>
        </svg>
      );
    }
    
    if (shapeKey.includes("pentagon") || shapeKey.includes("pentagram")) {
      const points = Array.from({ length: 5 }, (_, i) => {
        const angle = (i * 2 * Math.PI) / 5 - Math.PI / 2;
        return `${100 + 80 * Math.cos(angle)},${100 + 80 * Math.sin(angle)}`;
      }).join(" ");
      
      return (
        <svg viewBox="0 0 200 200" className={className}>
          <defs>
            <filter id="glow">
              <feGaussianBlur stdDeviation="2" result="coloredBlur"/>
              <feMerge>
                <feMergeNode in="coloredBlur"/>
                <feMergeNode in="SourceGraphic"/>
              </feMerge>
            </filter>
          </defs>
          <polygon
            points={points}
            fill="none"
            stroke="currentColor"
            strokeWidth="3"
            filter="url(#glow)"
          />
          <text
            x="100"
            y="115"
            textAnchor="middle"
            className="text-4xl font-serif font-bold"
            fill="currentColor"
          >
            {number}
          </text>
        </svg>
      );
    }
    
    if (shapeKey.includes("hexagon") || shapeKey.includes("hexagram")) {
      const points = Array.from({ length: 6 }, (_, i) => {
        const angle = (i * 2 * Math.PI) / 6 - Math.PI / 2;
        return `${100 + 80 * Math.cos(angle)},${100 + 80 * Math.sin(angle)}`;
      }).join(" ");
      
      return (
        <svg viewBox="0 0 200 200" className={className}>
          <defs>
            <filter id="glow">
              <feGaussianBlur stdDeviation="2" result="coloredBlur"/>
              <feMerge>
                <feMergeNode in="coloredBlur"/>
                <feMergeNode in="SourceGraphic"/>
              </feMerge>
            </filter>
          </defs>
          <polygon
            points={points}
            fill="none"
            stroke="currentColor"
            strokeWidth="3"
            filter="url(#glow)"
          />
          <text
            x="100"
            y="115"
            textAnchor="middle"
            className="text-4xl font-serif font-bold"
            fill="currentColor"
          >
            {number}
          </text>
        </svg>
      );
    }
    
    if (shapeKey.includes("heptagon") || shapeKey.includes("heptagram")) {
      const points = Array.from({ length: 7 }, (_, i) => {
        const angle = (i * 2 * Math.PI) / 7 - Math.PI / 2;
        return `${100 + 80 * Math.cos(angle)},${100 + 80 * Math.sin(angle)}`;
      }).join(" ");
      
      return (
        <svg viewBox="0 0 200 200" className={className}>
          <defs>
            <filter id="glow">
              <feGaussianBlur stdDeviation="2" result="coloredBlur"/>
              <feMerge>
                <feMergeNode in="coloredBlur"/>
                <feMergeNode in="SourceGraphic"/>
              </feMerge>
            </filter>
          </defs>
          <polygon
            points={points}
            fill="none"
            stroke="currentColor"
            strokeWidth="3"
            filter="url(#glow)"
          />
          <text
            x="100"
            y="115"
            textAnchor="middle"
            className="text-4xl font-serif font-bold"
            fill="currentColor"
          >
            {number}
          </text>
        </svg>
      );
    }
    
    if (shapeKey.includes("octagon") || shapeKey.includes("octagram")) {
      const points = Array.from({ length: 8 }, (_, i) => {
        const angle = (i * 2 * Math.PI) / 8 - Math.PI / 2;
        return `${100 + 80 * Math.cos(angle)},${100 + 80 * Math.sin(angle)}`;
      }).join(" ");
      
      return (
        <svg viewBox="0 0 200 200" className={className}>
          <defs>
            <filter id="glow">
              <feGaussianBlur stdDeviation="2" result="coloredBlur"/>
              <feMerge>
                <feMergeNode in="coloredBlur"/>
                <feMergeNode in="SourceGraphic"/>
              </feMerge>
            </filter>
          </defs>
          <polygon
            points={points}
            fill="none"
            stroke="currentColor"
            strokeWidth="3"
            filter="url(#glow)"
          />
          <text
            x="100"
            y="115"
            textAnchor="middle"
            className="text-4xl font-serif font-bold"
            fill="currentColor"
          >
            {number}
          </text>
        </svg>
      );
    }
    
    if (shapeKey.includes("nonagon") || shapeKey.includes("crescent")) {
      return (
        <svg viewBox="0 0 200 200" className={className}>
          <defs>
            <filter id="glow">
              <feGaussianBlur stdDeviation="2" result="coloredBlur"/>
              <feMerge>
                <feMergeNode in="coloredBlur"/>
                <feMergeNode in="SourceGraphic"/>
              </feMerge>
            </filter>
          </defs>
          <path
            d="M 120 30 A 70 70 0 1 1 120 170 A 50 50 0 1 0 120 30"
            fill="none"
            stroke="currentColor"
            strokeWidth="3"
            filter="url(#glow)"
          />
          <text
            x="90"
            y="115"
            textAnchor="middle"
            className="text-4xl font-serif font-bold"
            fill="currentColor"
          >
            {number}
          </text>
        </svg>
      );
    }
    
    // Default: Circle
    return (
      <svg viewBox="0 0 200 200" className={className}>
        <defs>
          <filter id="glow">
            <feGaussianBlur stdDeviation="2" result="coloredBlur"/>
            <feMerge>
              <feMergeNode in="coloredBlur"/>
              <feMergeNode in="SourceGraphic"/>
            </feMerge>
          </filter>
        </defs>
        <circle
          cx="100"
          cy="100"
          r="80"
          fill="none"
          stroke="currentColor"
          strokeWidth="3"
          filter="url(#glow)"
        />
        <text
          x="100"
          y="115"
          textAnchor="middle"
          className="text-4xl font-serif font-bold"
          fill="currentColor"
        >
          {number}
        </text>
      </svg>
    );
  };

  return <div className={color}>{renderShape()}</div>;
}
