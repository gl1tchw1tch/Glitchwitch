import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { PlanetaryIcon, getPlanetaryColor, getPlanetaryBorderColor } from "./planetary-icon";
import type { MagicalGoal } from "@shared/schema";

interface MagicalGoalCardProps {
  goal: MagicalGoal;
}

export function MagicalGoalCard({ goal }: MagicalGoalCardProps) {
  const ruler = goal.ruler;
  const borderColor = ruler ? getPlanetaryBorderColor(ruler) : "border-border";
  const planetColor = ruler ? getPlanetaryColor(ruler) : "text-muted-foreground";

  return (
    <Card 
      className={`p-5 border-l-4 ${borderColor} hover-elevate`}
      data-testid={`card-goal-${goal.squareNo}`}
    >
      <div className="flex items-start justify-between gap-3 mb-3">
        <div className="flex-1">
          <div className="flex items-center gap-2 mb-2">
            <span className="text-2xl font-serif font-bold text-muted-foreground" data-testid={`text-square-${goal.squareNo}`}>
              {goal.squareNo}
            </span>
            <Badge variant="secondary" className="text-xs" data-testid={`badge-category-${goal.squareNo}`}>
              {goal.category}
            </Badge>
          </div>
          <p className="text-foreground font-medium leading-relaxed mb-3" data-testid={`text-purpose-${goal.squareNo}`}>
            {goal.purpose}
          </p>
          {goal.matrix && (
            <div className="mt-3 p-3 bg-muted/30 rounded border border-muted">
              <p className="text-xs text-muted-foreground uppercase tracking-wide mb-1">Square Matrix</p>
              <p className="text-xs font-mono text-foreground" data-testid={`text-matrix-${goal.squareNo}`}>
                {goal.matrix}
              </p>
            </div>
          )}
        </div>
        {ruler && (
          <div className={`${planetColor} flex-shrink-0`} data-testid={`icon-ruler-${goal.squareNo}`}>
            <PlanetaryIcon planet={ruler} className="w-8 h-8" />
          </div>
        )}
      </div>
    </Card>
  );
}
