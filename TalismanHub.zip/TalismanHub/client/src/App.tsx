import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import Home from "@/pages/home";
import MagicalGoals from "@/pages/magical-goals";
import NotFound from "@/pages/not-found";
import { Button } from "@/components/ui/button";
import { Link, useLocation } from "wouter";
import { BookOpen, Home as HomeIcon } from "lucide-react";

function Navigation() {
  const [location] = useLocation();
  
  return (
    <nav className="fixed bottom-6 right-6 z-50 flex gap-2">
      {location !== "/" && (
        <Link href="/">
          <Button
            size="icon"
            variant="default"
            className="rounded-full shadow-lg"
            data-testid="nav-home"
          >
            <HomeIcon className="w-5 h-5" />
          </Button>
        </Link>
      )}
      {location !== "/magical-goals" && (
        <Link href="/magical-goals">
          <Button
            size="icon"
            variant="default"
            className="rounded-full shadow-lg"
            data-testid="nav-goals"
          >
            <BookOpen className="w-5 h-5" />
          </Button>
        </Link>
      )}
    </nav>
  );
}

function Router() {
  return (
    <>
      <Switch>
        <Route path="/" component={Home} />
        <Route path="/magical-goals" component={MagicalGoals} />
        <Route component={NotFound} />
      </Switch>
      <Navigation />
    </>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <Toaster />
        <Router />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
