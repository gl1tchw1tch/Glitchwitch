import { z } from "zod";

// ============================================================================
// LUMINARY (Planetary) DATA STRUCTURE
// ============================================================================

export const luminarySchema = z.object({
  name: z.enum(["Sun", "Moon", "Mars", "Mercury", "Jupiter", "Venus", "Saturn"]),
  primaryColors: z.array(z.string()),
  shape: z.string(),
  number: z.number(),
  intelligence: z.string(),
  function: z.string(),
});

export type Luminary = z.infer<typeof luminarySchema>;

// ============================================================================
// SPIRIT (Intelligence) DATA STRUCTURE
// ============================================================================

export const spiritSchema = z.object({
  name: z.string(),
  planet: z.enum(["Sun", "Moon", "Mars", "Mercury", "Jupiter", "Venus", "Saturn"]),
  secondaryColors: z.array(z.string()),
  symbols: z.array(z.string()),
});

export type Spirit = z.infer<typeof spiritSchema>;

// ============================================================================
// MAGICAL GOAL DATA STRUCTURE
// ============================================================================

export const magicalGoalCategorySchema = z.enum([
  "Divination",
  "Adversarial",
  "Spirit Work",
  "Alchemy",
  "Warding",
  "Fortune/Wealth",
  "Success",
  "Elemental/Alchemy",
  "Elemental",
  "Defense/Warding",
  "Knowledge",
  "Love/Attraction",
  "Transformation",
  "Healing",
  "Malefic Work",
  "Legal/Justice",
  "Revelation",
  "Spirit Work/Adversarial",
]);

export type MagicalGoalCategory = z.infer<typeof magicalGoalCategorySchema>;

export const magicalGoalSchema = z.object({
  squareNo: z.number(),
  purpose: z.string(),
  category: magicalGoalCategorySchema,
  matrix: z.string().optional(),
  ruler: z.enum(["Sun", "Moon", "Mars", "Mercury", "Jupiter", "Venus", "Saturn"]).optional(),
});

export type MagicalGoal = z.infer<typeof magicalGoalSchema>;

// ============================================================================
// TRANSIT DATA STRUCTURE
// ============================================================================

export const transitSchema = z.object({
  id: z.number(),
  luminary: z.enum(["Sun", "Moon", "Mars", "Mercury", "Jupiter", "Venus", "Saturn"]),
  date: z.string(),
  time: z.string(),
  aspect: z.string(),
  target: z.string(),
  sign: z.string(),
  intent: z.string(),
});

export type Transit = z.infer<typeof transitSchema>;

// ============================================================================
// NATAL CHART CONTEXT DATA STRUCTURE
// ============================================================================

export const natalContextSchema = z.object({
  name: z.string(),
  dob: z.string(),
  tob: z.string(),
  location: z.string(),
  natalMercurySign: z.string(),
  keyAspect: z.string(),
});

export type NatalContext = z.infer<typeof natalContextSchema>;

// ============================================================================
// BLUEPRINT DATA STRUCTURE (Generated from Transit + Luminary + Spirit)
// ============================================================================

export const blueprintSchema = z.object({
  transit: transitSchema,
  luminary: luminarySchema,
  spirit: spiritSchema,
  combinedColors: z.array(z.string()),
  generatedAt: z.string(),
});

export type Blueprint = z.infer<typeof blueprintSchema>;

// ============================================================================
// GOAL-TO-RULER MAPPING
// ============================================================================

export const GOAL_TO_RULER_MAP: Record<MagicalGoalCategory, "Sun" | "Moon" | "Mars" | "Mercury" | "Jupiter" | "Venus" | "Saturn"> = {
  "Divination": "Mercury",
  "Adversarial": "Mars",
  "Spirit Work": "Sun",
  "Alchemy": "Mercury",
  "Warding": "Saturn",
  "Fortune/Wealth": "Jupiter",
  "Success": "Jupiter",
  "Elemental/Alchemy": "Moon",
  "Elemental": "Moon",
  "Defense/Warding": "Saturn",
  "Knowledge": "Mercury",
  "Love/Attraction": "Venus",
  "Transformation": "Moon",
  "Healing": "Moon",
  "Malefic Work": "Saturn",
  "Legal/Justice": "Jupiter",
  "Revelation": "Mercury",
  "Spirit Work/Adversarial": "Mars",
};
