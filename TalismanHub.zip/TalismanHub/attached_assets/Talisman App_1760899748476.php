<?php
// PHP Telismatic Election Hub
// A single-file application for generating talismanic blueprints based on upcoming astrological transits.

// --- 1. CONFIGURATION & DATABASES ---

// User's Natal Chart Data (Used for context and identifying target planets for transits)
$natal_chart = [
    'name' => 'Prava Sex M',
    'dob' => '1987-06-11',
    'tob' => '22:46',
    'location' => 'Decatur, GA, USA',
    'natal_mercury_sign' => 'Cancer',
    'key_aspect' => 'Natal Mercury (Function) Afflicted by Mars in Cancer (Focus for Clarity)',
];

// LUMINARY CORRESPONDENCES (Primary source for core design elements - Shape, Number, Color)
$luminaries = [
    'Sun' => ['color' => 'Intense yellow-white, Pale golden yellow', 'shape' => 'Hexagon or Hexagram', 'number' => 6, 'intelligence' => 'Nakhiel', 'function' => 'Success, Vitality, Power'],
    'Moon' => ['color' => 'Red-purple, Violet, Lavender, Pale lemon yellow', 'shape' => 'Nonagon or Crescent', 'number' => 9, 'intelligence' => 'Malkah b\'Tarshishim', 'function' => 'Intuition, Emotions, Protection'],
    'Mars' => ['color' => 'Amber, Red, Fiery red, Pale yellow/cerise', 'shape' => 'Pentagon or Pentagram', 'number' => 5, 'intelligence' => 'Graphiel', 'function' => 'Courage, Strength, Protection'],
    'Mercury' => ['color' => 'Yellow ochre, Orange, Light apricot, Yellowish-white', 'shape' => 'Octagon or Octagram', 'number' => 8, 'intelligence' => 'Tiriel', 'function' => 'Communication, Intellect, Speed'],
    'Jupiter' => ['color' => 'Lilac, Blue, Light royal blue, Nacreous green-blue', 'shape' => 'Square', 'number' => 4, 'intelligence' => 'Yophiel', 'function' => 'Wealth, Growth, Success'],
    'Venus' => ['color' => 'Greenish blue, Green, Light turquoise, Luminescent greenish-white', 'shape' => 'Heptagon or Heptagram', 'number' => 7, 'intelligence' => 'Hagiel', 'function' => 'Love, Beauty, Creativity'],
    'Saturn' => ['color' => 'Dove grey, Indigo, Soft red-brown, Grey with fulvous shades', 'shape' => 'Triangle', 'number' => 3, 'intelligence' => 'Agiel', 'function' => 'Stability, Protection, Endurance'],
];

// SPIRIT DATABASE (Secondary correspondences and associated symbols for refinement and intent)
$spirits = [
    'Tiriel' => ['planet' => 'Mercury', 'secondary_colors' => ['Silver', 'Grey', 'Iris'], 'associated_symbol' => 'Caduceus Staff, Scrolls, Wings/Feathers'],
    'Yophiel' => ['planet' => 'Jupiter', 'secondary_colors' => ['White', 'Gold', 'Sapphire'], 'associated_symbol' => 'Crown/Scepter, Wheel of Fortune, Oak Tree/Laurel Wreath'],
    'Graphiel' => ['planet' => 'Mars', 'secondary_colors' => ['Black', 'Brown', 'Iron'], 'associated_symbol' => 'Swords/Spears, Flames/Fire Icons, Shield/Armor Motifs'],
    'Agiel' => ['planet' => 'Saturn', 'secondary_colors' => ['Silver', 'Stone', 'Lead'], 'associated_symbol' => 'Rings/Chains, Hourglass/Clock, Mountains/Stone Patterns'],
    'Nakhiel' => ['planet' => 'Sun', 'secondary_colors' => ['Gold', 'Orange', 'Red'], 'associated_symbol' => 'Solar Disk/Sunburst, Lion Iconography, Crown/Laurel Wreaths'],
    'Hagiel' => ['planet' => 'Venus', 'secondary_colors' => ['Copper', 'Turquoise'], 'associated_symbol' => 'Roses/Flowers, Heart Motifs, Doves/Swans'],
    'Malkah b\'Tarshishim' => ['planet' => 'Moon', 'secondary_colors' => ['White', 'Silver', 'Water'], 'associated_symbol' => 'Crescent Moon Icons, Water Imagery (Waves/Tides), Stars'],
];

// MAGICAL GOALS (Derived from your CSV)
$magical_goals = [
    ['square_no' => 1, 'purpose' => 'To know all things past and future.', 'category' => 'Divination'],
    ['square_no' => 6, 'purpose' => 'To know the past of an enemy.', 'category' => 'Adversarial'],
    ['square_no' => 10, 'purpose' => 'To do damage to an enemy with a spirit familiar.', 'category' => 'Adversarial'],
    ['square_no' => 17, 'purpose' => 'To cause a person to reveal all hidden secrets.', 'category' => 'Revelation'],
    ['square_no' => 20, 'purpose' => 'To receive information about all things pertaining to law.', 'category' => 'Legal/Justice'],
    ['square_no' => 118, 'purpose' => 'To cause hostilities to occur between people of the cloth.', 'category' => 'Malefic Work'],
    ['square_no' => 123, 'purpose' => 'To find stolen items.', 'category' => 'Divination'],
    ['square_no' => 130, 'purpose' => 'To make your guardian angel appear before you.', 'category' => 'Spirit Work'],
];

// CONCEPTUAL GOAL-TO-RULER MAPPING (Used to connect the CSV purpose to a Luminary)
$goal_to_ruler_map = [
    'Divination' => 'Mercury', // Clarity, knowledge, secrets
    'Adversarial' => 'Mars', // Conflict, aggression, action
    'Malefic Work' => 'Saturn', // Restriction, binding, darkness
    'Revelation' => 'Mercury', // Uncovering, communication
    'Legal/Justice' => 'Jupiter', // Law, fairness, expansion of authority
    'Transformation' => 'Moon', // Changes, phases, shifts
    'Spirit Work' => 'Sun', // Authority, high spirits, power
];

// UPCOMING TRANSITS (Manual feed of pre-calculated astrological opportunities)
$upcoming_transits = [
    // This is the example from your Mercury/Tiriel request
    [
        'id' => 1,
        'luminary' => 'Mercury',
        'date' => '2025-11-03',
        'time' => '16:45',
        'aspect' => 'Trine',
        'target' => 'Natal Mercury',
        'sign' => 'In Scorpio',
        'intent' => 'Foster intellectual clarity and strategic communication.',
    ],
    // NEW ENTRY: Example of an Adversarial work from your CSV
    [
        'id' => 5,
        'luminary' => 'Mars',
        'date' => '2025-11-20',
        'time' => '23:15',
        'aspect' => 'Conjunction',
        'target' => 'Natal Mars',
        'sign' => 'In Aquarius',
        'intent' => 'Adversarial Work: To know the past of an enemy (Square 6).',
    ],
    [
        'id' => 2,
        'luminary' => 'Jupiter',
        'date' => '2025-11-15',
        'time' => '09:20',
        'aspect' => 'Sextile',
        'target' => 'Natal Sun',
        'sign' => 'In Aries',
        'intent' => 'Attract financial opportunity and expansion.',
    ],
    [
        'id' => 3,
        'luminary' => 'Mars',
        'date' => '2025-11-20',
        'time' => '04:30',
        'aspect' => 'Square',
        'target' => 'Natal Moon',
        'sign' => 'In Aquarius',
        'intent' => 'For defense, protection, and transmuting conflict.',
    ],
    [
        'id' => 4,
        'luminary' => 'Saturn',
        'date' => '2025-11-28',
        'time' => '19:00',
        'aspect' => 'Conjunction',
        'target' => 'Natal Venus',
        'sign' => 'In Capricorn',
        'intent' => 'Establish long-term emotional boundaries and stability.',
    ],
];

// --- 2. LOGIC FOR BLUEPRINT GENERATION ---

$blueprint = null;

if (isset($_GET['recommend_id'])) {
    $id = (int)$_GET['recommend_id'];
    $selected_transit = array_filter($upcoming_transits, fn($t) => $t['id'] === $id);

    if (!empty($selected_transit)) {
        $transit = reset($selected_transit);
        $luminary_name = $transit['luminary'];
        $luminary_data = $luminaries[$luminary_name] ?? null;

        if ($luminary_data) {
            $spirit_name = $luminary_data['intelligence'];
            $spirit_data = $spirits[$spirit_name] ?? ['secondary_colors' => [], 'associated_symbol' => 'N/A'];

            // Combine primary and secondary colors
            $primary_colors = explode(', ', $luminary_data['color']);
            $secondary_colors = $spirit_data['secondary_colors'];
            $final_colors = array_merge($primary_colors, $secondary_colors);

            $blueprint = [
                'luminary' => $luminary_name,
                'spirit' => $spirit_name,
                'date' => $transit['date'],
                'time' => $transit['time'],
                'aspect' => "{$transit['aspect']} to {$transit['target']} ({$transit['sign']})",
                'intent' => $transit['intent'],
                'shape' => $luminary_data['shape'],
                'number' => $luminary_data['number'],
                'colors' => implode(', ', array_unique($final_colors)),
                'symbol' => $spirit_data['associated_symbol'],
            ];
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Telismatic Election Hub</title>
    <!-- Load Tailwind CSS -->
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700&display=swap" rel="stylesheet">
    <style>
        body {
            font-family: 'Inter', sans-serif;
            background-color: #0d1117; /* Dark background for a ritual feel */
            color: #c9d1d9;
        }
        .card {
            background-color: #161b22;
            border: 1px solid #30363d;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.2);
        }
        .btn-primary {
            background-color: #38a169; /* Green for action */
            color: white;
            transition: background-color 0.2s;
            white-space: nowrap; /* Ensures button text doesn't wrap on mobile */
        }
        .btn-primary:hover {
            background-color: #2f855a;
        }
        .luminary-tag {
            font-size: 1.1rem;
            font-weight: 700;
        }
        /* Custom color mapping based on your data */
        .text-Mercury { color: #facc15; } /* Yellow */
        .text-Jupiter { color: #818cf8; } /* Blue/Purple */
        .text-Mars { color: #ef4444; } /* Red */
        .text-Venus { color: #34d399; } /* Green */
        .text-Sun { color: #f59e0b; } /* Gold */
        .text-Moon { color: #c4b5fd; } /* Lavender */
        .text-Saturn { color: #4b5563; } /* Grey */
        .border-Mercury { border-color: #facc15; }
        .border-Jupiter { border-color: #818cf8; }
        .border-Mars { border-color: #ef4444; }
        .border-Saturn { border-color: #4b5563; }
        .border-Sun { border-color: #f59e0b; }
        .border-Venus { border-color: #34d399; }
        .border-Moon { border-color: #c4b5fd; }
    </style>
</head>
<body class="p-4 md:p-8 min-h-screen">

    <div class="max-w-4xl mx-auto">
        <h1 class="text-4xl font-bold text-center text-white mb-6">
            Telismatic Election Hub
        </h1>
        <p class="text-center text-gray-400 mb-8">
            Filter upcoming astrological transits against your natal chart to generate the **vector design blueprint**.
        </p>

        <!-- NATAL CONTEXT CARD -->
        <div class="card p-5 rounded-xl mb-8">
            <h2 class="text-2xl font-semibold border-b border-gray-700 pb-3 mb-4 text-green-400">Natal Context</h2>
            <div class="grid grid-cols-2 gap-4 text-sm">
                <div>
                    <p class="text-gray-500">Natal Chart ID</p>
                    <p class="font-bold text-white"><?= htmlspecialchars($natal_chart['name']) ?></p>
                </div>
                <div>
                    <p class="text-gray-500">Key Focus Aspect</p>
                    <p class="font-bold text-red-300"><?= htmlspecialchars($natal_chart['key_aspect']) ?></p>
                </div>
                <div>
                    <p class="text-gray-500">DOB/Time/Location</p>
                    <p class="text-white"><?= htmlspecialchars($natal_chart['dob'] . ' @ ' . $natal_chart['tob']) ?> / <?= htmlspecialchars($natal_chart['location']) ?></p>
                </div>
                <div>
                    <p class="text-gray-500">Core Affliction</p>
                    <p class="text-white">Mercury in **<?= htmlspecialchars($natal_chart['natal_mercury_sign']) ?>**</p>
                </div>
            </div>
        </div>

        <!-- BLUEPRINT OUTPUT SECTION -->
        <?php if ($blueprint): ?>
            <div class="card p-6 rounded-xl mb-8 bg-purple-900/30 border-purple-700">
                <h2 class="text-3xl font-bold text-purple-400 mb-4">Final Talismanic Blueprint</h2>
                <p class="text-gray-300 mb-4">
                    Blueprint based on the **<?= htmlspecialchars($blueprint['luminary']) ?>** election, refined by the Intelligence **<?= htmlspecialchars($blueprint['spirit']) ?>**.
                </p>

                <div class="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
                    <div class="bg-gray-800/50 p-4 rounded-lg border-l-4 border-<?= htmlspecialchars($blueprint['luminary']) ?>">
                        <p class="text-gray-400">Election Date/Time</p>
                        <p class="text-xl font-bold text-white">
                            <?= htmlspecialchars(date('D, M j, Y', strtotime($blueprint['date']))) ?> @ <?= htmlspecialchars($blueprint['time']) ?>
                        </p>
                        <p class="text-sm text-yellow-300 mt-1">
                            **Aspect:** <?= htmlspecialchars($blueprint['aspect']) ?>
                        </p>
                    </div>
                    <div class="bg-gray-800/50 p-4 rounded-lg border-l-4 border-<?= htmlspecialchars($blueprint['luminary']) ?>">
                        <p class="text-gray-400">Primary Intent</p>
                        <p class="text-xl font-bold text-white"><?= htmlspecialchars($blueprint['intent']) ?></p>
                        <p class="text-sm text-gray-400 mt-1">Intelligence of <?= htmlspecialchars($blueprint['luminary']) ?> is invoked.</p>
                    </div>
                </div>

                <!-- VECTOR DESIGN ELEMENTS -->
                <div class="bg-gray-900 p-4 rounded-lg border border-gray-700">
                    <h3 class="text-xl font-semibold text-purple-300 mb-3">Vector Design Coordinates (A.S.A.P.)</h3>
                    <div class="grid grid-cols-2 md:grid-cols-4 text-center gap-4">
                        <div>
                            <p class="text-gray-400 text-sm">Primary Shape</p>
                            <p class="text-xl font-extrabold text-white break-words"><?= htmlspecialchars($blueprint['shape']) ?></p>
                        </div>
                        <div>
                            <p class="text-gray-400 text-sm">Core Number (Qabalistic)</p>
                            <p class="text-xl font-extrabold text-white"><?= htmlspecialchars($blueprint['number']) ?></p>
                        </div>
                        <div class="col-span-2">
                            <p class="text-gray-400 text-sm">Full Color Palette (Luminary + Spirit)</p>
                            <p class="text-md font-extrabold text-white break-words"><?= htmlspecialchars($blueprint['colors']) ?></p>
                        </div>
                        <div class="col-span-full">
                            <p class="text-gray-400 text-sm">Suggested Symbol / Motif</p>
                            <p class="text-lg font-bold text-yellow-200"><?= htmlspecialchars($blueprint['symbol']) ?></p>
                        </div>
                    </div>
                </div>
            </div>
        <?php endif; ?>


        <!-- UPCOMING OPPORTUNITIES FEED -->
        <div class="card p-5 rounded-xl">
            <h2 class="text-2xl font-semibold border-b border-gray-700 pb-3 mb-4 text-yellow-400">
                Upcoming Talismanic Opportunities (The Initiation)
            </h2>
            <p class="text-gray-400 mb-4">Transits interacting with your Natal Chart. Click to generate the blueprint.</p>

            <div class="space-y-4">
                <?php foreach ($upcoming_transits as $transit): 
                    $luminary_data = $luminaries[$transit['luminary']];
                    $spirit_name = $luminary_data['intelligence'];
                ?>
                    <div class="p-4 rounded-lg flex flex-col md:flex-row justify-between items-start md:items-center bg-gray-800/50 hover:bg-gray-800 transition duration-150 border-l-4 border-<?= htmlspecialchars($transit['luminary']) ?>">
                        <div class="mb-3 md:mb-0 md:w-3/4">
                            <div class="flex items-center space-x-2">
                                <span class="luminary-tag text-<?= htmlspecialchars($transit['luminary']) ?>">
                                    <?= htmlspecialchars($transit['luminary']) ?>
                                </span>
                                <span class="text-gray-300 font-medium text-sm">
                                    <?= htmlspecialchars($transit['aspect']) ?> to <?= htmlspecialchars($transit['target']) ?> in <?= htmlspecialchars($transit['sign']) ?>
                                </span>
                            </div>
                            <p class="text-sm text-gray-400 mt-1">
                                Goal: <?= htmlspecialchars($transit['intent']) ?>
                            </p>
                            <p class="text-xs text-gray-500 mt-1">
                                **Ruler:** <?= htmlspecialchars($transit['luminary']) ?> (<?= htmlspecialchars($luminary_data['shape']) ?>/<?= htmlspecialchars($luminary_data['number']) ?>) | **Intelligence:** <?= htmlspecialchars($spirit_name) ?>
                            </p>
                        </div>
                        <div class="md:text-right flex flex-col items-start md:items-end">
                            <span class="text-sm font-semibold text-white">
                                <?= htmlspecialchars(date('M j', strtotime($transit['date']))) ?> @ <?= htmlspecialchars($transit['time']) ?>
                            </span>
                            <a href="?recommend_id=<?= $transit['id'] ?>" class="btn-primary px-3 py-1 mt-2 text-sm rounded-full">
                                Generate Blueprint
                            </a>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>
        
        <!-- MAGICAL GOALS DATABASE VIEW (For reference) -->
        <div class="card p-5 rounded-xl mt-8">
            <h2 class="text-2xl font-semibold border-b border-gray-700 pb-3 mb-4 text-blue-400">
                Magical Goal Database (from CSV)
            </h2>
            <div class="space-y-3">
                <?php foreach ($magical_goals as $goal):
                    $category = $goal['category'];
                    $ruler = $goal_to_ruler_map[$category] ?? 'Unknown';
                ?>
                    <div class="p-3 bg-gray-900/50 rounded-lg border-l-2 border-<?= htmlspecialchars($ruler) ?>">
                        <p class="text-sm font-medium text-white">
                            **Square <?= htmlspecialchars($goal['square_no']) ?>:** <?= htmlspecialchars($goal['purpose']) ?>
                        </p>
                        <p class="text-xs text-gray-400 mt-0.5">
                            Category: <?= htmlspecialchars($category) ?> | Suggested Ruler: <span class="text-<?= htmlspecialchars($ruler) ?> font-semibold"><?= htmlspecialchars($ruler) ?></span>
                        </p>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>

    </div>
</body>
</html>

