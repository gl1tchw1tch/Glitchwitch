# Telismatic Election Hub

## Overview

The Telismatic Election Hub is a specialized web application for generating talismanic design blueprints based on astrological elections, planetary correspondences, and sacred geometry. The application combines astrological data (natal charts, transits) with esoteric knowledge systems (Qabalistic numerology, planetary intelligences, magical goals) to produce visual design specifications for talismanic workings.

**Core Purpose**: The system analyzes favorable astrological transits against a user's natal chart and generates detailed design blueprints that specify geometric forms, color palettes, symbolic motifs, and ritual timing for creating physical talismans aligned with specific magical intentions.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture

**Framework & Build System**:
- React 18 with TypeScript in strict mode
- Vite as the build tool and development server
- Single-page application (SPA) using Wouter for client-side routing
- Path aliases configured for clean imports (`@/`, `@shared/`, `@assets/`)

**UI Component System**:
- Shadcn UI component library (New York style variant) with Radix UI primitives
- TailwindCSS for styling with custom design tokens
- Dark mode as primary theme with Material Design foundation enhanced with mystical/esoteric aesthetics
- Custom planetary color system with semantic colors for different luminaries (Sun, Moon, Mars, Mercury, Jupiter, Venus, Saturn)

**Typography & Fonts**:
- Inter (Google Fonts) - Primary UI text and data display
- Cinzel (Google Fonts) - Headers and mystical elements
- JetBrains Mono (Google Fonts) - Technical data and matrices

**State Management**:
- TanStack Query (React Query) for server state management
- Query client configured with infinite stale time and disabled refetching
- Custom query functions with error handling and 401 unauthorized behavior

**Key Design Principles**:
- Hybrid approach balancing data clarity with sacred/mystical aesthetics
- Hierarchical information revelation from overview to detailed specifications
- Planetary resonance through visual language reflecting celestial correspondences
- Professional mysticism with scholarly approach to esoteric content

### Backend Architecture

**Server Framework**:
- Express.js server with TypeScript
- Custom middleware for request logging and error handling
- RESTful API design pattern

**Development Environment**:
- Vite middleware integration for HMR in development
- Production build serves static files from dist/public
- Environment-aware configuration (NODE_ENV)

**API Endpoints**:
- `GET /api/natal-context` - Retrieves user's natal chart information
- `GET /api/transits?luminary={planet}` - Fetches upcoming astrological transits with optional filtering
- `GET /api/transits/:id/blueprint` - Generates complete talismanic design blueprint for a specific transit

**Data Storage Strategy**:
- In-memory storage implementation using Maps for quick lookups
- Five core data arrays: Luminaries, Spirits, Magical Goals, Transits, Natal Context
- No database persistence in current implementation (data initialized on server start)

**Blueprint Generation Logic**:
- Combines transit data with luminary correspondences and spirit attributes
- Merges primary colors from planetary ruler with secondary colors from intelligence
- Associates geometric forms, numbers, and symbolic motifs
- Outputs comprehensive design specifications including timing and intent

### Data Model

**Core Entities** (defined in `shared/schema.ts` with Zod validation):

1. **Luminary** (Planetary Ruler):
   - Name, primary colors, geometric shape, qabalistic number
   - Intelligence name and magical function
   - 7 planets: Sun, Moon, Mars, Mercury, Jupiter, Venus, Saturn

2. **Spirit** (Planetary Intelligence):
   - Name, associated planet, secondary colors, symbolic motifs
   - Provides refinement layer for design elements

3. **Magical Goal**:
   - Square number (reference ID), purpose description, category
   - Optional square matrix data
   - Associated planetary ruler (derived from purpose)
   - 15+ categories including Divination, Adversarial, Spirit Work, Alchemy, etc.

4. **Transit**:
   - Date, time, luminary, aspect type, target planet/point, astrological sign
   - Intent description linking to magical purpose
   - References natal chart positions

5. **Natal Context**:
   - User's birth data, key astrological aspects, core afflictions
   - Serves as foundation for transit analysis

6. **Blueprint** (Generated):
   - Transit information, luminary data, spirit data
   - Combined color palette, symbolic elements
   - Generation timestamp

### External Dependencies

**UI Component Libraries**:
- Radix UI - Headless accessible component primitives (accordion, dialog, dropdown, select, tabs, toast, tooltip, etc.)
- Embla Carousel - Carousel/slider functionality
- Lucide React - Icon system

**Data & Forms**:
- React Hook Form with Zod resolvers for form validation
- date-fns for date formatting and manipulation
- Drizzle ORM with Zod integration (configured but not actively used in current implementation)

**Styling**:
- TailwindCSS with PostCSS and Autoprefixer
- class-variance-authority for component variant management
- clsx and tailwind-merge for className utilities

**Database** (Configured but not actively used):
- Neon Database serverless PostgreSQL driver (@neondatabase/serverless)
- Drizzle Kit for schema migrations
- Connection configured via DATABASE_URL environment variable
- Schema file at `shared/schema.ts`, migrations output to `./migrations`

**Development Tools**:
- Replit-specific plugins for development banner and cartographer
- Runtime error overlay for better debugging

**Build & Runtime**:
- esbuild for server bundling
- tsx for TypeScript execution in development
- nanoid for unique ID generation