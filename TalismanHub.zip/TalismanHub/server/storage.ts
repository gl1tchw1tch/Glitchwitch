import type { 
  Luminary, 
  Spirit, 
  MagicalGoal, 
  Transit, 
  NatalContext,
  MagicalGoalCategory 
} from "@shared/schema";
import { GOAL_TO_RULER_MAP } from "@shared/schema";

export interface IStorage {
  // Luminary operations
  getLuminaries(): Promise<Luminary[]>;
  getLuminaryByName(name: string): Promise<Luminary | undefined>;
  
  // Spirit operations
  getSpirits(): Promise<Spirit[]>;
  getSpiritByName(name: string): Promise<Spirit | undefined>;
  
  // Magical Goal operations
  getMagicalGoals(category?: MagicalGoalCategory): Promise<MagicalGoal[]>;
  getMagicalGoalBySquareNo(squareNo: number): Promise<MagicalGoal | undefined>;
  
  // Transit operations
  getTransits(luminary?: string): Promise<Transit[]>;
  getTransitById(id: number): Promise<Transit | undefined>;
  
  // Natal Context operations
  getNatalContext(): Promise<NatalContext>;
}

export class MemStorage implements IStorage {
  private luminaries: Map<string, Luminary>;
  private spirits: Map<string, Spirit>;
  private magicalGoals: Map<number, MagicalGoal>;
  private transits: Map<number, Transit>;
  private natalContext: NatalContext;

  constructor() {
    this.luminaries = new Map();
    this.spirits = new Map();
    this.magicalGoals = new Map();
    this.transits = new Map();
    
    // Initialize all databases
    this.initializeLuminaries();
    this.initializeSpirits();
    this.initializeMagicalGoals();
    this.initializeTransits();
    this.initializeNatalContext();
  }

  private initializeLuminaries() {
    const luminariesData: Luminary[] = [
      {
        name: "Sun",
        primaryColors: ["Intense yellow-white", "Pale golden yellow"],
        shape: "Hexagon or Hexagram",
        number: 6,
        intelligence: "Nakhiel",
        function: "Success, Vitality, Power",
      },
      {
        name: "Moon",
        primaryColors: ["Red-purple", "Violet", "Lavender", "Pale lemon yellow"],
        shape: "Nonagon or Crescent",
        number: 9,
        intelligence: "Malkah b'Tarshishim",
        function: "Intuition, Emotions, Protection",
      },
      {
        name: "Mars",
        primaryColors: ["Amber", "Red", "Fiery red", "Pale yellow/cerise"],
        shape: "Pentagon or Pentagram",
        number: 5,
        intelligence: "Graphiel",
        function: "Courage, Strength, Protection",
      },
      {
        name: "Mercury",
        primaryColors: ["Yellow ochre", "Orange", "Light apricot", "Yellowish-white"],
        shape: "Octagon or Octagram",
        number: 8,
        intelligence: "Tiriel",
        function: "Communication, Intellect, Speed",
      },
      {
        name: "Jupiter",
        primaryColors: ["Lilac", "Blue", "Light royal blue", "Nacreous green-blue"],
        shape: "Square",
        number: 4,
        intelligence: "Yophiel",
        function: "Wealth, Growth, Success",
      },
      {
        name: "Venus",
        primaryColors: ["Greenish blue", "Green", "Light turquoise", "Luminescent greenish-white"],
        shape: "Heptagon or Heptagram",
        number: 7,
        intelligence: "Hagiel",
        function: "Love, Beauty, Creativity",
      },
      {
        name: "Saturn",
        primaryColors: ["Dove grey", "Indigo", "Soft red-brown", "Grey with fulvous shades"],
        shape: "Triangle",
        number: 3,
        intelligence: "Agiel",
        function: "Stability, Protection, Endurance",
      },
    ];

    luminariesData.forEach((lum) => this.luminaries.set(lum.name, lum));
  }

  private initializeSpirits() {
    const spiritsData: Spirit[] = [
      {
        name: "Tiriel",
        planet: "Mercury",
        secondaryColors: ["Silver", "Grey", "Iris"],
        symbols: ["Caduceus Staff", "Scrolls", "Wings/Feathers"],
      },
      {
        name: "Yophiel",
        planet: "Jupiter",
        secondaryColors: ["White", "Gold", "Sapphire"],
        symbols: ["Crown/Scepter", "Wheel of Fortune", "Oak Tree/Laurel Wreath"],
      },
      {
        name: "Graphiel",
        planet: "Mars",
        secondaryColors: ["Black", "Brown", "Iron"],
        symbols: ["Swords/Spears", "Flames/Fire Icons", "Shield/Armor Motifs"],
      },
      {
        name: "Agiel",
        planet: "Saturn",
        secondaryColors: ["Silver", "Stone", "Lead"],
        symbols: ["Rings/Chains", "Hourglass/Clock", "Mountains/Stone Patterns"],
      },
      {
        name: "Nakhiel",
        planet: "Sun",
        secondaryColors: ["Gold", "Orange", "Red"],
        symbols: ["Solar Disk/Sunburst", "Lion Iconography", "Crown/Laurel Wreaths"],
      },
      {
        name: "Hagiel",
        planet: "Venus",
        secondaryColors: ["Copper", "Turquoise"],
        symbols: ["Roses/Flowers", "Heart Motifs", "Doves/Swans"],
      },
      {
        name: "Malkah b'Tarshishim",
        planet: "Moon",
        secondaryColors: ["White", "Silver", "Water"],
        symbols: ["Crescent Moon Icons", "Water Imagery (Waves/Tides)", "Stars"],
      },
    ];

    spiritsData.forEach((spirit) => this.spirits.set(spirit.name, spirit));
  }

  private initializeMagicalGoals() {
    const goalsData: Array<Omit<MagicalGoal, "ruler"> & { ruler?: MagicalGoal["ruler"] }> = [
      { squareNo: 1, purpose: "To know all things past and future.", category: "Divination", matrix: "M I L O N, I R A G O, L A M A L, O G A R I, N O L I M" },
      { squareNo: 2, purpose: "To foresee major events.", category: "Divination", matrix: "H I R A M A, H I G A N A M, I G G A N A, R A G I G A R, A N A G O G I, M A N A G I H, A M A R I H T" },
      { squareNo: 3, purpose: "To know secret past events that have been kept hidden.", category: "Divination" },
      { squareNo: 4, purpose: "To know major upsets in the world that are to come.", category: "Divination", matrix: "R A P I, A A R P, K K A R, P R I A R A, P A R A S" },
      { squareNo: 5, purpose: "To know the things that will make the world better in time to come.", category: "Divination", matrix: "M A L A C H, A M A N E C, L A N A N A, A N A N A L, C E N A M A, H C A L A M" },
      { squareNo: 6, purpose: "To know the past of an enemy.", category: "Adversarial", matrix: "K O S E M, O B O D, S O F O S, E D O B O, M E S O K" },
      { squareNo: 7, purpose: "To see future fierce storms, and where they will occur.", category: "Divination", matrix: "R O T H E R, O R O R I E, T O A R A H, H A R A O T, E I R O R O, R E H T O R" },
      { squareNo: 8, purpose: "To detect true and false friends.", category: "Divination" },
      { squareNo: 9, purpose: "To be able to successfully undertake alchemical experiments.", category: "Alchemy", matrix: "A L L U P, L E I R U, L I G I L, U R I E L, P U L L A" },
      { squareNo: 10, purpose: "To be able to successfully undertake alchemical experiments.", category: "Alchemy" },
      { squareNo: 11, purpose: "To be able to successfully undertake alchemical experiments.", category: "Alchemy" },
      { squareNo: 12, purpose: "To summon a serpent spirit to appear before you.", category: "Spirit Work", matrix: "U R I E L, R A M I E, I M I M I, E I M A R, L E I R U" },
      { squareNo: 13, purpose: "To summon a spirit taking any animal form to appear before you.", category: "Spirit Work", matrix: "L U C I F E R, U N A N I M E, C A T O N I F, I N O N O N I, F I N O T A C, E M I N A N U, R E F I C U L" },
      { squareNo: 14, purpose: "To summon a human spirit to appear before you.", category: "Spirit Work" },
      { squareNo: 15, purpose: "For divining the future using a mirror or crystal.", category: "Divination" },
      { squareNo: 16, purpose: "For divining the future using minerals.", category: "Divination" },
      { squareNo: 17, purpose: "For divining the future using the clouds.", category: "Divination", matrix: "A P P A R E T, A P P A R E T" },
      { squareNo: 18, purpose: "For divining the future using the rings in tree stumps.", category: "Divination", matrix: "B E D S E R, E L I E L E, D I A P I S, S E P P E D, E L I E L E, R E S D E B" },
      { squareNo: 19, purpose: "For divining the future using the reflections of the moon upon water.", category: "Divination", matrix: "G O H E N, O R A R E, H A S A H, E R A R O, N E H O G" },
      { squareNo: 20, purpose: "For divining the future through pyromancy, the interpreting of flames in fire.", category: "Divination", matrix: "A D M O N, D, M, O, N" },
      { squareNo: 21, purpose: "For divining the future through cheiromancy, the reading of hands.", category: "Divination", matrix: "L E L E H, E, L, E, H" },
      { squareNo: 22, purpose: "To summon a dog spirit to appear before you.", category: "Spirit Work", matrix: "C U S I S, U, S, I, S" },
      { squareNo: 23, purpose: "To summon a spirit taking the form of a soldier to appear before you.", category: "Spirit Work", matrix: "R I S I R, I S E R I, S E K E S, I R E P I, R I S I R" },
      { squareNo: 24, purpose: "To summon a spirit taking the form of an old man to appear before you.", category: "Spirit Work", matrix: "N E S E R, E L E H E, S E P E E, E H E E E, E E E E N" },
      { squareNo: 25, purpose: "To secure home protection.", category: "Warding" },
      { squareNo: 26, purpose: "To detect precious stones, metals etc.", category: "Fortune/Wealth" },
      { squareNo: 27, purpose: "To make found riches become public.", category: "Fortune/Wealth" },
      { squareNo: 28, purpose: "To make impossible tasks easily successful.", category: "Success" },
      { squareNo: 29, purpose: "To make mountain climbing safe and easy.", category: "Success" },
      { squareNo: 30, purpose: "To make water drain from mines.", category: "Elemental/Alchemy", matrix: "A K A B, N A K A R" },
      { squareNo: 31, purpose: "To make it snow.", category: "Elemental", matrix: "T A K A T, T A K A T, T A K A T, A K A T" },
      { squareNo: 32, purpose: "To make it thunder.", category: "Elemental" },
      { squareNo: 33, purpose: "To make it rain.", category: "Elemental", matrix: "S A G R I R, A, G, R, I, R" },
      { squareNo: 34, purpose: "To render any 'negative' spells cast against you useless.", category: "Defense/Warding" },
      { squareNo: 35, purpose: "To cure anyone who is possessed by dark forces.", category: "Defense/Warding" },
      { squareNo: 36, purpose: "To dissolve astral entities.", category: "Spirit Work" },
      { squareNo: 37, purpose: "To understand astrological charts.", category: "Knowledge", matrix: "C O L I, O D A C, L A C A, I C A R" },
      { squareNo: 38, purpose: "To understand all about magic.", category: "Knowledge" },
      { squareNo: 39, purpose: "To understand alchemy.", category: "Knowledge", matrix: "K E H A H E K, E, H, A, H, E, K" },
      { squareNo: 40, purpose: "To find out other people's secrets.", category: "Divination" },
      { squareNo: 41, purpose: "To understand foreign languages.", category: "Knowledge" },
      { squareNo: 42, purpose: "To find out undercover experiments.", category: "Divination", matrix: "M A A B H A D, A A B H A D" },
      { squareNo: 43, purpose: "To find out government secrets that are kept from the general public.", category: "Divination" },
      { squareNo: 44, purpose: "To know how to receive love from any person you wish.", category: "Love/Attraction" },
      { squareNo: 45, purpose: "To find out any person's bank balance.", category: "Divination" },
      { squareNo: 46, purpose: "To understand the meaning of existence and creation.", category: "Knowledge", matrix: "M E L A B A H, E, L, A, B, A, H" },
      { squareNo: 47, purpose: "To converse with those who have passed-on.", category: "Spirit Work" },
      { squareNo: 48, purpose: "To converse with those who have passed-on.", category: "Spirit Work" },
      { squareNo: 49, purpose: "To converse with those who have passed-on.", category: "Spirit Work", matrix: "I O S U A, O R I L U, S I S I S, U L I R O, A U S O I" },
      { squareNo: 50, purpose: "To converse with those who have passed-on.", category: "Spirit Work", matrix: "P E G E R, E T I A E, G I S I G, E A I T E, R E G E P" },
      { squareNo: 51, purpose: "To gain invisibility.", category: "Transformation" },
      { squareNo: 52, purpose: "To gain invisibility.", category: "Transformation" },
      { squareNo: 53, purpose: "To gain invisibility.", category: "Transformation", matrix: "C A S A H, A D O D A, S O M O S, A D O P A, H A S A C" },
      { squareNo: 54, purpose: "To gain invisibility.", category: "Transformation" },
      { squareNo: 55, purpose: "To gain invisibility.", category: "Transformation", matrix: "C O D E R, . 0, D, E, R" },
      { squareNo: 56, purpose: "To gain invisibility.", category: "Transformation", matrix: "S I M L A H, I, M, L, A S I I R I, H, S" },
      { squareNo: 57, purpose: "To gain invisibility.", category: "Transformation", matrix: "C E H A H, E, H, A, H" },
      { squareNo: 58, purpose: "To gain invisibility.", category: "Transformation", matrix: "A N A N A, A N A N A" },
      { squareNo: 59, purpose: "To gain invisibility.", category: "Transformation" },
      { squareNo: 60, purpose: "To gain invisibility.", category: "Transformation" },
      { squareNo: 61, purpose: "To gain invisibility.", category: "Transformation", matrix: "T A L A C, A, A, L, L, A, A, C A L A T" },
      { squareNo: 62, purpose: "To gain invisibility.", category: "Transformation" },
      { squareNo: 63, purpose: "To receive large amounts of money and precious stones and metals.", category: "Fortune/Wealth" },
      { squareNo: 64, purpose: "To receive large amounts of money and precious stones and metals.", category: "Fortune/Wealth", matrix: "C E S E P, E, S, E, P" },
      { squareNo: 65, purpose: "To receive large amounts of money and precious stones and metals.", category: "Fortune/Wealth" },
      { squareNo: 66, purpose: "To receive large amounts of money and precious stones and metals.", category: "Fortune/Wealth", matrix: "N E C O T, N E C O T, H" },
      { squareNo: 67, purpose: "To receive large amounts of money and precious stones and metals.", category: "Fortune/Wealth", matrix: "M A G O T, A R A T O, G A L A G, O T A R A, T O G A M" },
      { squareNo: 68, purpose: "To receive large amounts of money and precious stones and metals.", category: "Fortune/Wealth", matrix: "A G I L, N I L I, A, K" },
      { squareNo: 69, purpose: "To receive large amounts of money and precious stones and metals.", category: "Fortune/Wealth", matrix: "C O S E N, O, S, E, N" },
      { squareNo: 70, purpose: "To receive large amounts of money and precious stones and metals.", category: "Fortune/Wealth", matrix: "O T S A R, O T S A R" },
      { squareNo: 71, purpose: "To receive large amounts of money and precious stones and metals.", category: "Fortune/Wealth", matrix: "B E L I A L, E B O R U A, L O V A R I, R A V O L, A V R O B E, L A I L E B" },
      { squareNo: 72, purpose: "To receive large amounts of money and precious stones and metals.", category: "Fortune/Wealth", matrix: "O R I O N, R A V R O, I V A V I, O R V A R, O I R O" },
      { squareNo: 73, purpose: "To receive large amounts of money and precious stones and metals.", category: "Fortune/Wealth", matrix: "E R M A, K E R, M, A" },
      { squareNo: 74, purpose: "To receive large amounts of money and precious stones and metals.", category: "Fortune/Wealth", matrix: "I A N A, K, A M E N, N E M A, A N A I" },
      { squareNo: 75, purpose: "To receive large amounts of money and precious stones and metals.", category: "Fortune/Wealth" },
      { squareNo: 76, purpose: "To receive large amounts of money and precious stones and metals.", category: "Fortune/Wealth" },
      { squareNo: 77, purpose: "To receive large amounts of money and precious stones and metals.", category: "Fortune/Wealth" },
      { squareNo: 78, purpose: "To receive large amounts of money and precious stones and metals.", category: "Fortune/Wealth", matrix: "A S T A R O T, S A L I S T O, T L A N B S R, Α I N O N I A, R S B N A L T, O T S I L A S, T O R A T S A" },
      { squareNo: 79, purpose: "To receive large amounts of money and precious stones and metals.", category: "Fortune/Wealth", matrix: "K O N E H, K O N E U, H, K" },
      { squareNo: 80, purpose: "To receive large amounts of money and precious stones and metals.", category: "Fortune/Wealth", matrix: "C A H I L, A, H, I, L" },
      { squareNo: 81, purpose: "To receive large amounts of money and precious stones and metals.", category: "Fortune/Wealth", matrix: "A R I T O N, R O C A R O, I C L O A T, T A O L O R, O R A C O R, N O T I R A" },
      { squareNo: 82, purpose: "To receive large amounts of money and precious stones and metals.", category: "Fortune/Wealth", matrix: "O R I M E L, R E M O R E, I M O N O N, N O N O M I, E R O M E R, L E I N R O" },
      { squareNo: 83, purpose: "To cure agrophobia.", category: "Healing" },
      { squareNo: 84, purpose: "To cure sore palms and feet.", category: "Healing", matrix: "B U A H" },
      { squareNo: 85, purpose: "To cure ulcers.", category: "Healing" },
      { squareNo: 86, purpose: "To cure claustrophobia.", category: "Healing", matrix: "R E C H E M, E R H A S E, C H A I A H, H A I A H C, E S A H R E, M E H C E R" },
      { squareNo: 87, purpose: "To cure arthritis.", category: "Healing", matrix: "R O K E A, O G I R E, K I L I K, E R I G O, A E K O R" },
      { squareNo: 88, purpose: "To cure influenza.", category: "Healing", matrix: "B E T E M, E M E R E, T E N E T, E R E M E, M E T E B" },
      { squareNo: 89, purpose: "To cure cramp.", category: "Healing", matrix: "B E B H E R, E R A O S E, B A R I O H, H O I R A B, E S O A R E, R E H B E B" },
      { squareNo: 90, purpose: "To cure seasickness.", category: "Healing", matrix: "E L E O S, L A B I O, E B I B E, O I B A L, S O E L E" },
      { squareNo: 91, purpose: "To cure phobia of heights.", category: "Healing" },
      { squareNo: 92, purpose: "To cure migraine headaches.", category: "Healing" },
      { squareNo: 93, purpose: "To cure excessive fluid in the body.", category: "Healing", matrix: "S I T U R, I R A P E, T A R A G, U P A L A, R E G A N" },
      { squareNo: 94, purpose: "To cure battle wounds.", category: "Healing", matrix: "H A P P I R, A M A O S I, P A R A O P, P O A R A P, I S O A M A, R I P P A H" },
      { squareNo: 95, purpose: "To receive endless love from your spouse.", category: "Love/Attraction", matrix: "D O D I M, O, D, I, M" },
      { squareNo: 96, purpose: "To obtain the love of someone very special to you.", category: "Love/Attraction", matrix: "R A I A H, A, I G O G I, A, H A I A H" },
      { squareNo: 97, purpose: "To obtain love from your family.", category: "Love/Attraction", matrix: "M O D A H, O K O R A, D, A, H" },
      { squareNo: 98, purpose: "To obtain the love of a specific female.", category: "Love/Attraction" },
      { squareNo: 99, purpose: "To obtain the friendship of those who deal in legal matters.", category: "Love/Attraction" },
      { squareNo: 100, purpose: "To obtain love from someone married.", category: "Love/Attraction" },
      { squareNo: 101, purpose: "To obtain love from a widow.", category: "Love/Attraction", matrix: "E L E M, L, E, M" },
      { squareNo: 102, purpose: "To obtain love from any female.", category: "Love/Attraction", matrix: "S A L O M, A R E P O, L E M E L, O P E R A, M O L A S" },
      { squareNo: 103, purpose: "To obtain love from a special male.", category: "Love/Attraction", matrix: "D E B A M, E R E R A, B E R E B, A R E R E, M A B E D" },
      { squareNo: 104, purpose: "To obtain love from a special 'mature' male.", category: "Love/Attraction", matrix: "A H H B, B, E, A, R" },
      { squareNo: 105, purpose: "To obtain a special friendship from a specific person.", category: "Love/Attraction" },
      { squareNo: 106, purpose: "To obtain love from a high ranking officer.", category: "Love/Attraction" },
      { squareNo: 107, purpose: "To obtain love from a high ranking female.", category: "Love/Attraction" },
      { squareNo: 108, purpose: "To obtain love from people of the cloth.", category: "Love/Attraction" },
      { squareNo: 109, purpose: "To obtain 'Astral' lovers.", category: "Love/Attraction" },
      { squareNo: 110, purpose: "To obtain the love of a discarnate mistress.", category: "Love/Attraction" },
      { squareNo: 111, purpose: "To cause hatred between chosen people.", category: "Malefic Work", matrix: "K A N N A, A Q A I, N A T A, N I A Q A, A" },
      { squareNo: 112, purpose: "To cause ill-feelings in general.", category: "Malefic Work", matrix: "S E L A K, E, L, A I A R E, K" },
      { squareNo: 113, purpose: "To cause fights between chosen people.", category: "Malefic Work", matrix: "R O Q E N, O, O, Q O I O R, E, N E Q O N" },
      { squareNo: 114, purpose: "To cause specific ill-feelings.", category: "Malefic Work", matrix: "A T L I T I S, T, L O Q O S A T, I, T A S O Q O L, I, S" },
      { squareNo: 115, purpose: "To cause ill-feelings between specific females.", category: "Malefic Work", matrix: "O T S A M A H, T, S, M A K A R O S, A, A, H" },
      { squareNo: 116, purpose: "To cause a specific army to turn on their chiefs.", category: "Malefic Work", matrix: "L O F I T O S, I K O N O K I, O, F, T, O, S" },
      { squareNo: 117, purpose: "To cause any kind of argument to occur between chosen people.", category: "Malefic Work", matrix: "G I B O R, I, B I L E T, O, R" },
      { squareNo: 118, purpose: "To cause hostilities to occur between people of the cloth.", category: "Malefic Work", matrix: "N O K A M, O R O T A, K O B A K, A T A M O, M A K O N" },
      { squareNo: 119, purpose: "To transform yourself to look mature.", category: "Transformation" },
      { squareNo: 120, purpose: "To transform yourself to look like an old female.", category: "Transformation" },
      { squareNo: 121, purpose: "To transform yourself to look young.", category: "Transformation" },
      { squareNo: 122, purpose: "To transform yourself to look look like a young woman.", category: "Transformation", matrix: "I O N E K, O, N, E, Q, K" },
      { squareNo: 123, purpose: "To find stolen items.", category: "Divination" },
      { squareNo: 124, purpose: "To find stolen items.", category: "Divination" },
      { squareNo: 125, purpose: "To find stolen items.", category: "Divination" },
      { squareNo: 126, purpose: "To find stolen items.", category: "Divination" },
      { squareNo: 127, purpose: "To find stolen items.", category: "Divination" },
      { squareNo: 128, purpose: "To find stolen items.", category: "Divination" },
      { squareNo: 129, purpose: "To be able to swim in water as a fish can.", category: "Transformation" },
      { squareNo: 130, purpose: "To make your guardian angel appear before you.", category: "Spirit Work", matrix: "M A C A N E H, A, A C A N E, H" },
      { squareNo: 131, purpose: "To make your guardian angel fight on your behalf.", category: "Spirit Work" },
      { squareNo: 132, purpose: "To make your guardian angel carry out any kind of revenge that you owe to certain people.", category: "Spirit Work/Adversarial" },
    ];

    // Add ruler to each goal based on category
    const goalsWithRuler: MagicalGoal[] = goalsData.map(goal => ({
      ...goal,
      ruler: GOAL_TO_RULER_MAP[goal.category],
    }));

    goalsWithRuler.forEach((goal) => this.magicalGoals.set(goal.squareNo, goal));
  }

  private initializeTransits() {
    const transitsData: Transit[] = [
      {
        id: 1,
        luminary: "Mercury",
        date: "2025-11-03",
        time: "16:45",
        aspect: "Trine",
        target: "Natal Mercury",
        sign: "In Scorpio",
        intent: "Foster intellectual clarity and strategic communication.",
      },
      {
        id: 2,
        luminary: "Jupiter",
        date: "2025-11-15",
        time: "09:20",
        aspect: "Sextile",
        target: "Natal Sun",
        sign: "In Aries",
        intent: "Attract financial opportunity and expansion.",
      },
      {
        id: 3,
        luminary: "Mars",
        date: "2025-11-20",
        time: "04:30",
        aspect: "Square",
        target: "Natal Moon",
        sign: "In Aquarius",
        intent: "For defense, protection, and transmuting conflict.",
      },
      {
        id: 4,
        luminary: "Saturn",
        date: "2025-11-28",
        time: "19:00",
        aspect: "Conjunction",
        target: "Natal Venus",
        sign: "In Capricorn",
        intent: "Establish long-term emotional boundaries and stability.",
      },
      {
        id: 5,
        luminary: "Mars",
        date: "2025-11-20",
        time: "23:15",
        aspect: "Conjunction",
        target: "Natal Mars",
        sign: "In Aquarius",
        intent: "Adversarial Work: To know the past of an enemy (Square 6).",
      },
    ];

    transitsData.forEach((transit) => this.transits.set(transit.id, transit));
  }

  private initializeNatalContext() {
    this.natalContext = {
      name: "Prava Sex M",
      dob: "1987-06-11",
      tob: "22:46",
      location: "Decatur, GA, USA",
      natalMercurySign: "Cancer",
      keyAspect: "Natal Mercury (Function) Afflicted by Mars in Cancer (Focus for Clarity)",
    };
  }

  // Luminary methods
  async getLuminaries(): Promise<Luminary[]> {
    return Array.from(this.luminaries.values());
  }

  async getLuminaryByName(name: string): Promise<Luminary | undefined> {
    return this.luminaries.get(name);
  }

  // Spirit methods
  async getSpirits(): Promise<Spirit[]> {
    return Array.from(this.spirits.values());
  }

  async getSpiritByName(name: string): Promise<Spirit | undefined> {
    return this.spirits.get(name);
  }

  // Magical Goal methods
  async getMagicalGoals(category?: MagicalGoalCategory): Promise<MagicalGoal[]> {
    const allGoals = Array.from(this.magicalGoals.values());
    if (category) {
      return allGoals.filter((goal) => goal.category === category);
    }
    return allGoals;
  }

  async getMagicalGoalBySquareNo(squareNo: number): Promise<MagicalGoal | undefined> {
    return this.magicalGoals.get(squareNo);
  }

  // Transit methods
  async getTransits(luminary?: string): Promise<Transit[]> {
    const allTransits = Array.from(this.transits.values());
    if (luminary) {
      return allTransits.filter((transit) => transit.luminary === luminary);
    }
    return allTransits;
  }

  async getTransitById(id: number): Promise<Transit | undefined> {
    return this.transits.get(id);
  }

  // Natal Context methods
  async getNatalContext(): Promise<NatalContext> {
    return this.natalContext;
  }
}

export const storage = new MemStorage();
