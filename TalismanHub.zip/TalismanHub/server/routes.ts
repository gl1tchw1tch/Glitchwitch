import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import type { Blueprint } from "@shared/schema";

export async function registerRoutes(app: Express): Promise<Server> {
  // GET /api/natal-context
  app.get("/api/natal-context", async (req, res) => {
    try {
      const natalContext = await storage.getNatalContext();
      res.json(natalContext);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch natal context" });
    }
  });

  // GET /api/transits?luminary=Mars
  app.get("/api/transits", async (req, res) => {
    try {
      const luminary = req.query.luminary as string | undefined;
      const transits = await storage.getTransits(luminary || undefined);
      res.json(transits);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch transits" });
    }
  });

  // GET /api/transits/:id/blueprint
  app.get("/api/transits/:id/blueprint", async (req, res) => {
    try {
      const transitId = parseInt(req.params.id, 10);
      
      if (isNaN(transitId)) {
        res.status(400).json({ error: "Invalid transit ID" });
        return;
      }

      const transit = await storage.getTransitById(transitId);
      
      if (!transit) {
        res.status(404).json({ error: "Transit not found" });
        return;
      }

      // Get luminary data
      const luminary = await storage.getLuminaryByName(transit.luminary);
      
      if (!luminary) {
        res.status(404).json({ error: "Luminary not found" });
        return;
      }

      // Get spirit data based on the luminary's intelligence
      const spirit = await storage.getSpiritByName(luminary.intelligence);
      
      if (!spirit) {
        res.status(404).json({ error: "Spirit not found" });
        return;
      }

      // Merge primary and secondary colors
      const combinedColors = [
        ...luminary.primaryColors,
        ...spirit.secondaryColors,
      ];

      // Create blueprint
      const blueprint: Blueprint = {
        transit,
        luminary,
        spirit,
        combinedColors,
        generatedAt: new Date().toISOString(),
      };

      res.json(blueprint);
    } catch (error) {
      console.error("Error generating blueprint:", error);
      res.status(500).json({ error: "Failed to generate blueprint" });
    }
  });

  // GET /api/magical-goals?category=Divination
  app.get("/api/magical-goals", async (req, res) => {
    try {
      const category = req.query.category as string | undefined;
      const goals = await storage.getMagicalGoals(
        category as any || undefined
      );
      res.json(goals);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch magical goals" });
    }
  });

  const httpServer = createServer(app);

  return httpServer;
}
