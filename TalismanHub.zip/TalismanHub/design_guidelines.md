# Telismatic Election Hub - Design Guidelines

## Design Approach

**Hybrid Approach**: Material Design foundation with heavy mystical/esoteric customization. This application requires data clarity (utility-focused) while maintaining sacred/mystical aesthetics befitting talismanic work.

**Design Principles**:
- Sacred Functionality: Every element serves both practical and symbolic purposes
- Hierarchical Revelation: Information unfolds progressively from overview to detailed specifications
- Planetary Resonance: Visual language reflects celestial correspondences
- Professional Mysticism: Serious, scholarly approach to esoteric content

## Core Design Elements

### A. Color Palette

**Dark Mode Foundation** (Primary):
- Background: 210 15% 7% (deep cosmic void)
- Surface Cards: 215 20% 11% (elevated ritual space)
- Surface Elevated: 215 18% 14%
- Border Subtle: 215 15% 20%
- Border Strong: 215 25% 30%

**Planetary Color System** (Functional Accent Colors):
- Mercury: 45 95% 55% (brilliant yellow-gold)
- Mars: 0 85% 60% (intense red)
- Jupiter: 240 70% 65% (royal blue-violet)
- Venus: 160 75% 55% (emerald green)
- Sun: 35 90% 55% (solar gold)
- Moon: 260 65% 75% (luminous lavender)
- Saturn: 220 10% 40% (stone grey)

**Semantic Colors**:
- Success/Active: 142 70% 45%
- Warning: 35 85% 55%
- Danger: 0 75% 55%
- Info: 210 80% 60%

**Text Hierarchy**:
- Primary Text: 210 20% 85%
- Secondary Text: 210 15% 60%
- Tertiary/Muted: 210 10% 45%
- Inverted (on colored backgrounds): 210 20% 98%

### B. Typography

**Font Families**:
- Primary: 'Inter' (Google Fonts) - Clean, modern sans-serif for data/UI
- Accent/Headers: 'Cinzel' (Google Fonts) - Classical serif for mystical gravitas
- Monospace: 'JetBrains Mono' (Google Fonts) - Technical data, square matrices

**Type Scale**:
- Display (Hero): 3rem (48px) / Bold / Cinzel
- H1 (Page Titles): 2.25rem (36px) / Bold / Cinzel
- H2 (Section Headers): 1.75rem (28px) / SemiBold / Cinzel
- H3 (Card Titles): 1.25rem (20px) / SemiBold / Inter
- Body Large: 1.125rem (18px) / Regular / Inter
- Body: 1rem (16px) / Regular / Inter
- Body Small: 0.875rem (14px) / Regular / Inter
- Caption: 0.75rem (12px) / Medium / Inter

### C. Layout System

**Spacing Primitives**: Use Tailwind units 2, 4, 6, 8, 12, 16, 20, 24 for consistent rhythm

**Grid System**:
- Max Container: max-w-7xl (1280px)
- Content Sections: max-w-6xl (1152px) for dense data
- Reading Content: max-w-4xl (896px) for text-heavy sections
- Sidebar/Filters: 280px-320px fixed width

**Responsive Breakpoints**:
- Mobile: base (< 640px) - Single column, stacked cards
- Tablet: md (768px) - 2-column grids where appropriate
- Desktop: lg (1024px) - Multi-column layouts, sidebar navigation
- Wide: xl (1280px) - Full feature layouts

**Section Padding**:
- Desktop: py-16 to py-20
- Tablet: py-12
- Mobile: py-8

### D. Component Library

**Navigation**:
- Top nav bar: Sticky, dark glass-morphic effect (backdrop-blur-lg)
- Logo/Title: Cinzel font with subtle glow effect on planetary symbol
- Nav links: Inter medium, planetary color on hover states
- User context indicator: Compact natal chart summary

**Cards** (Primary Container):
- Background: Surface color with subtle border
- Border-left accent: 4px planetary color stripe for categorization
- Padding: p-6 (desktop), p-4 (mobile)
- Hover: Subtle elevation increase, border glow in planetary color
- Corner radius: rounded-xl (12px)

**Transit Cards** (Specialized):
- Compact layout: Date/time prominent top-left
- Planetary glyph/icon: Large, colored, top-right
- Aspect description: Body text with highlighted natal target
- Intent text: Italic, secondary color
- CTA button: Right-aligned, planetary-colored

**Blueprint Display** (Featured Component):
- Large card with gradient background (planetary colors, subtle)
- Sacred geometry shape visualization: SVG, centered, large
- Specifications grid: 2-column on desktop, single on mobile
- Color swatches: Horizontal row of colored circles with labels
- Symbol suggestions: Icon set with descriptions
- Export/Print button: Prominent, bottom-right

**Data Tables**:
- Alternating row backgrounds for readability
- Sticky headers on scroll
- Planetary color coding in relevant columns
- Compact on mobile (card-style stacking)

**Magical Goals Browser**:
- Filterable card grid: 3 columns (desktop), 2 (tablet), 1 (mobile)
- Category tags: Small pills with category colors
- Square number: Large, prominent, top-left corner
- Purpose text: Clear hierarchy, readable
- Ruler indicator: Small planetary icon/badge

**Forms** (Goal Selection, Filters):
- Dark inputs with subtle borders
- Planetary-colored focus states
- Dropdown selectors for categories/rulers
- Clear labels with helper text
- Validation states using semantic colors

**Buttons**:
- Primary: Planetary-colored background, white text
- Secondary: Transparent with planetary-colored border/text
- Ghost: Text only, planetary-colored on hover
- Sizes: sm (py-2 px-4), md (py-3 px-6), lg (py-4 px-8)

**Icons**:
- Use Lucide React icon library via CDN
- Planetary glyphs: Custom SVG set (simplified astrological symbols)
- Size scale: 16px, 20px, 24px, 32px

### E. Animations

**Subtle Motion Only**:
- Card hover: transform scale(1.02), 200ms ease
- Button states: background color transitions, 150ms
- Page transitions: fade-in on load, 300ms
- Data loading: Pulse skeleton screens in surface color
- NO complex scroll animations or parallax effects

## Special Considerations

**Sacred Geometry Integration**:
- Blueprint shapes (hexagon, pentagon, octagon, etc.) rendered as crisp SVG
- Shapes use planetary primary colors with subtle inner glow
- Qabalistic numbers integrated into shape centers

**Planetary Color Application**:
- Use consistently across transit cards, tags, borders, and buttons
- Never mix planetary colors within single components
- Text on planetary backgrounds: always use inverted text color for contrast

**Information Density**:
- Balance detail with readability - use collapsible sections for complex data
- Natal chart context: Always visible but compact
- Blueprint specifications: Comprehensive but well-organized in grids

**Accessibility**:
- All planetary colors meet WCAG AA contrast requirements against dark backgrounds
- Focus indicators: 2px planetary-colored outline
- Keyboard navigation fully supported
- Screen reader labels for all symbols and glyphs

## Images

**No hero images required** - this is a data/utility application. Visual impact comes from:
- Planetary color system
- Sacred geometry SVG renderings in blueprint displays
- Mystical typography (Cinzel headers)
- Dark, cosmic aesthetic

**Icon/Symbol Usage**:
- Planetary glyphs as SVG icons throughout
- Optional: Subtle constellation patterns in background (very low opacity)
- Optional: Textured paper/parchment overlay on blueprint export view for printability